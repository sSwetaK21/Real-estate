import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { Button, Box } from '@mui/material';

import Cards from '../../Card/Cards';

function MainBox({ favs, setFavs }) {

    const [cards, setCards] = useState([]);
    const [searchName, setsearchName] = useState('');
    const [dropdowns, setDropdowns] = useState([]);
    const [loc, setLoc] = useState({
        locName: '',
        date: '',
        price: "",
        house: ""
    })

    useEffect(() => {
        axios
            .get("database.json")
            .then((res) => {
                // console.log(res.data)
                setCards(res.data)
                setDropdowns(res.data)
            })

    }, [])

    // Searching by Name 

    const handleSearchBar = () => {
        const searching = cards.filter((val) => {
            return val.name.toLowerCase().includes(searchName.toLowerCase())
        })
        setCards(searching);
    };

    const handleChange = (e) => {
        setLoc({ ...loc, [e.target.name]: e.target.value })
        // console.log(e.target.value, loc)
    }


    const handleSearchName = (e) => {
        setsearchName(e.target.value)
    }
    // filter fucntion here
    const handleDropdownSearch = () => {
        let priceRange = loc.price.split("-")

        // eslint-disable-next-line array-callback-return
        const dropDownsSearch = dropdowns.filter((value) => {
            // console.log(value, loc)
            let dateOne = new Date(loc.date).getTime();
            let dateTwo = new Date(value.date).getTime();
            if (value.location.toLowerCase().includes(loc.locName.toLowerCase()) 
            // && (value.type === loc.house || loc.house === "") &&
            //     ((parseInt(priceRange[0]) <= value.price &&
            //         parseInt(priceRange[1]) >= value.price) || loc.price === "") && (dateOne >= dateTwo || loc.date === "")
            ) {
                console.log("VALUEEEE",value)
                return value
            }
        })

        setCards(dropDownsSearch)
    }

    return (

        //Main body of Rent
        <div className="body">

            {/* search by name */}
            <div className='main'>
                <div className='searchLeft'>
                    <h1 className='h1Title'>Search properties to rent</h1>
                </div>
                <div className='searchrigt'>
                    <input type="text" className='saerchInput' value={searchName} placeholder="Search by Name" onChange={handleSearchName} />
                    <Button className='btnpurple' onClick={handleSearchBar}>Search</Button>

                </div>
            </div>

            {/* filtering div here */}

            <div className='searchBox'>
                <div className="loc" >
                    <Box sx={{ minWidth: 120 }}>
                        <div className="elBorder">
                            <p className='titles dropdownNames '>Location</p>
                            <select id="dropdown" name="locname" vale={loc.locName} onChange={handleChange
                            }>
                                <option value="N/A">Location</option>
                                <option value="Georgia" name="locname">
                                    Georgia
                                </option>
                                <option value="Newyork" name="locname">
                                    Newyork
                                </option>
                                <option value="Maryland" name="locname">
                                    Maryland
                                </option>
                            </select>
                        </div>
                    </Box>
                </div>
                <div className='date'>
                    <Box sx={{ minWidth: 180 }}>
                        <div className='elBorder'>

                            <h6 className='dropdownNames'>Date</h6>

                            <input type="date" id="dateinput" name="date" onChange={handleChange} />
                        </div>

                    </Box>
                </div>
                <div className='price'>
                    <Box sx={{ minWidth: 120 }}>
                        <div className="elBorder">
                            <h6 className='dropdownNames'>Price</h6>
                            <select id="dropdown" name="price" onChange={handleChange}>
                                <option value="N/A">Price</option>
                                <option value="1000-3000" name="price">
                                    1000-3000
                                </option>
                                <option value="3000-6000" name="price">
                                    3000-6000
                                </option>
                                <option value="6000- 9000" name="price">
                                    6000- 9000
                                </option>
                            </select>
                        </div>
                    </Box>
                </div>
                <div className='house'>
                    <Box sx={{ minWidth: 120 }}>
                        <div className="elBorder">
                            <h6 className='dropdownNames'>Property Type</h6>
                            <select id="dropdown" name="type" onChange={handleChange}>
                                <option value="House" name="type">
                                    House
                                </option>
                                <option value="Cottage" name="type">
                                    Cottage
                                </option>
                                <option value="Bangalow" name="type">
                                    Bangalow
                                </option>
                                <option value="Building" name="type">
                                    Building
                                </option>
                            </select>

                        </div>
                    </Box>
                </div>

                <Button sx={{ ml: '1rem' }} className='btnpurple' onClick={handleDropdownSearch}>Filter</Button>
            </div>

            {/* Fetching cards */}
            <div className='cardFlex'>
                {
                    cards.length ? cards.map(({ img, name, location, price, size, beds, bathrooms }) => {
                        return (

                            <Cards name={name} location={location} beds={beds} img={img}
                                bathrooms={bathrooms} price={price} size={size} isClicked favs={favs}
                                setFavs={setFavs}
                            />
                        )
                    }
                    )
                        : "no results found"
                }

            </div>
        </div>


    )
}

export default MainBox