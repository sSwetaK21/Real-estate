import React from 'react'

function Buy() {
    return (
        <div>Buy
            <h2>Hi this is Buy page</h2>
        </div>
    )
}

export default Buy