import React from 'react'

function Sell() {
  return (
    <div>Sell
                <h2>Hi this is Sell page</h2>

    </div>
  )
}

export default Sell